package com.runsim.backend;

public abstract class StateMachine {

}
